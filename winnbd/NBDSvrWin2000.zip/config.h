/* The number of bytes in a unsigned int.  */
#define SIZEOF_UNSIGNED_INT 4

/* The number of bytes in a unsigned long int.  */
#define SIZEOF_UNSIGNED_LONG_INT 4

/* The number of bytes in a unsigned long long int.  */
#define SIZEOF_UNSIGNED_INT_64 8

/* The number of bytes in a unsigned short int.  */
#define SIZEOF_UNSIGNED_SHORT_INT 2

/* Define if you have the llseek function.  */
/* #undef HAVE_LLSEEK */
